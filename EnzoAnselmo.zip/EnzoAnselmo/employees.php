<?php
require 'db_connect.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'GET') {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $stmt = $conn->prepare("SELECT * FROM Employee WHERE id = ?");
        $stmt->bind_param("i", $id);

        $stmt->execute();

        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $employee = $result->fetch_assoc();
            print json_encode($employee);
        } else {
            echo "Aucun employé avec cet ID.";
        }
    } else {
        $sql = "SELECT * FROM Employee";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $employees = array();
            while ($row = $result->fetch_assoc()) {
                $employees[] = $row;
            }
            print json_encode($employees);
        } else {
            echo "0 results";
        }
    }
} elseif ($method == 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    if (isset($data['name']) && isset($data['email']) && isset($data['age']) && isset($data['designation']) && isset($data['created'])) {
        $name = $data['name'];
        $email = $data['email'];
        $age = $data['age'];
        $designation = $data['designation'];
        $created = $data['created'];

        $stmt = $conn->prepare("INSERT INTO Employee (name, email, age, designation, created) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssiss", $name, $email, $age, $designation, $created);

        if ($stmt->execute()) {
            echo "Nouvel employé ajouté avec succès.";
        } else {
            echo "Erreur lors de l'ajout du nouvel employé.";
        }
    } else {
        echo "Données insuffisantes fournies pour créer un nouvel employé.";
    }
} elseif ($method == 'PUT') {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $data = json_decode(file_get_contents("php://input"), true);

        if (isset($data['name']) && isset($data['email']) && isset($data['age']) && isset($data['designation']) && isset($data['created'])) {
            $name = $data['name'];
            $email = $data['email'];
            $age = $data['age'];
            $designation = $data['designation'];
            $created = $data['created'];

            $stmt = $conn->prepare("UPDATE Employee SET name = ?, email = ?, age = ?, designation = ?, created = ? WHERE id = ?");
            $stmt->bind_param("ssissi", $name, $email, $age, $designation, $created, $id);

            if ($stmt->execute()) {
                echo "Employé mis à jour avec succès.";
            } else {
                echo "Erreur lors de la mise à jour de l'employé.";
            }
        } else {
            echo "Données insuffisantes fournies pour mettre à jour l'employé.";
        }
    } else {
        echo "Aucun ID d'employé fourni pour la mise à jour.";
    }
} elseif ($method == 'DELETE') {
    $data = json_decode(file_get_contents("php://input"), true);

    if (isset($data['id'])) {
        $id = $data['id'];

        $stmt = $conn->prepare("DELETE FROM Employee WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "Employé supprimé avec succès.";
        } else {
            echo "Erreur lors de la suppression de l'employé.";
        }
    } else {
        echo "ID d'employé manquant pour la suppression.";
    }
} else {
    echo "Méthode non prise en charge.";
}

$conn->close();
?>
